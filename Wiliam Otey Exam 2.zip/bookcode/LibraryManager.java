public class Manager {

    static DataAccess dao = new DataAccess();

    static BookView bookView = new BookView();

    static BookController bookController = new BookController(bookView, dao);

    public static void main(String[] args) {

        dao.connect();
        BookModel book = dao.loadBook(1); // Apple;
        if (book != null)
            System.out.println("Book with ID = " + book.bookID + " title = " + book.title + " author = " + book.author + " published year = " + book.year + " number of pages = " + book.year);

        book.bookID = 50;
        book.title = "Shin";
        book.author = "Megami";
        book.year = 2019;
        book.numPages = 50;

        dao.saveBook(book);

        book = dao.loadBook(100); // Samsung!!!
        if (book != null)
            System.out.println("Book with ID = " + book.bookID + " title = " + book.title + " author = " + book.author + " published year = " + book.year + " number of pages = " + book.year);
        bookView.show();
    }
}