package com.ausoft;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import com.google.gson.*;

public class Teller extends Thread {
    protected Socket socket;
    protected DataAccess dao;

    public Teller(Socket incoming, DataAccess dao) {
        this.socket = incoming;
        this.dao = dao;
    }

    public void run() {
        try {
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()));
            PrintWriter out = new PrintWriter(
                    new OutputStreamWriter(
                            socket.getOutputStream()));

            while (true) {
                String str = in.readLine();
                if (str == null) break; // client closed connection
                System.out.println("Received from client: " + str);

                Gson gson = new Gson();
                LibraryRequest request = gson.fromJson(str, LibraryRequest.class);
                LibraryResponse response = new LibraryResponse();


                if (request.code == LibraryRequest.GOOD_BYE) break; // the client wants to stop!

                if (request.code == LibraryRequest.LOAD_PRODUCT) {
                    int id = Integer.parseInt(request.data);
                    ProductModel prod = dao.loadProduct(id);

                    if (prod == null)
                        response.code = LibraryResponse.PRODUCT_NOT_FOUND;
                    else
                        response.data = gson.toJson(prod);

                    out.println(gson.toJson(response));
                    out.flush();
                    continue;
                }

                if (request.code == LibraryRequest.SAVE_PRODUCT) {
                    ProductModel prod = gson.fromJson(request.data, ProductModel.class);

                    if  (dao.saveProduct(prod))
                        response.code = LibraryResponse.OK;
                    else
                        response.code = LibraryResponse.SAVE_PRODUCT_ERROR;

                    out.println(gson.toJson(response));
                    out.flush();
                }
            }
            in.close();
            out.close();
            socket.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
