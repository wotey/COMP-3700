import javax.swing.*;
import javax.xml.crypto.Data;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BookController implements ActionListener {

    BookView myView;
    DataAccess myDB;
    public BookController(BookView view, DataAccess dao) {
        myView = view;
        myDB = dao;
        myView.btnLoad.addActionListener(this);
        myView.btnSave.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == myView.btnLoad) {      // button Load is clicked
            display();
        }

        if (e.getSource() == myView.btnSave) {      // button Load is clicked
            saveBook();
        }

    }

    private void saveBook() {
        BookModel productModel = new BookModel();

        try {
            int bookID  = Integer.parseInt(myView.txtBookID.getText());
            productModel.bookID = bookID;
            productModel.title = myView.txtBookTitle.getText();
            productModel.author = myView.txtBookAuthor.getText();
            productModel.year = Double.parseDouble(myView.txtBookPublishedYear.getText());
            productModel.numPages = Double.parseDouble(myView.txtBookNumPages.getText());

            myDB.saveBook(productModel);
            JOptionPane.showMessageDialog(null, "Product saved successfully!");


        }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid format for ProductID");
            ex.printStackTrace();
        }    }

    private void display() {
        BookModel book = new BookModel();
        try {
            int bookID = Integer.parseInt(myView.txtBookID.getText());
            BookModel bookModel = myDB.loadBook(bookID);
            myView.txtBookTitle.setText(book.title);
            myView.txtBookAuthor.setText(book.author);
            myView.txtBookPublishedYear.setText(String.valueOf(book.year));
            myView.txtBookNumPages.setText(String.valueOf(book.numPages));

        }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid format for ProductID");
            ex.printStackTrace();
        }
    }
}
