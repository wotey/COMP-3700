public class LibraryManager {

    static DataAccess dao = new DataAccess();

    static BookView bookView = new BookView();

    static BookController bookController = new BookController(bookView, dao);

    public static void main(String[] args) {

        dao.connect();
        BookModel book = dao.loadBook(1); // Apple;
        if (book != null)
            System.out.println("Book with ID = " + book.bookID + " title = " + book.title + " author = " + book.author + " published year = " + book.year + " number of pages = " + book.year);

        book.bookID = 100;
        book.title = "To Kill A Mockingbird";
        book.author = "Harper Lee";
        book.year = 1923;
        book.numPages = 400;

        dao.saveBook(book);

        book = dao.loadBook(100); // Samsung!!!
        if (book != null)
            System.out.println("Book with ID = " + book.bookID + " title = " + book.title + " author = " + book.author + " published year = " + book.year + " number of pages = " + book.year);
        bookView.show();
    }
}