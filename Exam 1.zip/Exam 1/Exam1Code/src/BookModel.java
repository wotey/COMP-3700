public class BookModel {
    public int bookID;
    public String title;
    public String author;
    public double year;
    public double numPages;
}
